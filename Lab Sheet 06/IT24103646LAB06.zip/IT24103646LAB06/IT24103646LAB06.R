setwd ("C:\\Users\\it24103646\\Desktop\\IT24103646LAB06")
data<-read.table("Data - Lab 8.txt",header=TRUE)
fix(data)
attach(data)
n <- 44
p <- 0.92

# i. Distribution of X
cat("Q1 (i): X ~ Binomial(", n, ",", p, ")\n")

# ii. P(X = 40)
cat("Q1 (ii): P(X=40) =", dbinom(40, size = n, prob = p), "\n")

# iii. P(X <= 35)
cat("Q1 (iii): P(X<=35) =", pbinom(35, size = n, prob = p), "\n")

# iv. P(X >= 38)
cat("Q1 (iv): P(X>=38) =", 1 - pbinom(37, size = n, prob = p), "\n")

# v. P(40 <= X <= 42)
cat("Q1 (v): P(40<=X<=42) =", 
    dbinom(40, n, p) + dbinom(41, n, p) + dbinom(42, n, p), "\n")

# -------------------------------
# Question 2 - Babies Born (Poisson)
# -------------------------------
lambda <- 5

# i. Random Variable
cat("\nQ2 (i): X = number of babies born per day\n")

# ii. Distribution
cat("Q2 (ii): X ~ Poisson(", lambda, ")\n")

# iii. P(X = 6)
cat("Q2 (iii): P(X=6) =", dpois(6, lambda), "\n")

# iv. P(X > 6)
cat("Q2 (iv): P(X>6) =", 1 - ppois(6, lambda), "\n")

# -------------------------------
# Exercise 1 - Learning Platform
# -------------------------------
n <- 50
p <- 0.85

# i. Distribution
cat("\nExercise 1 (i): X ~ Binomial(", n, ",", p, ")\n")

# ii. P(X >= 47)
cat("Exercise 1 (ii): P(X>=47) =", 1 - pbinom(46, size = n, prob = p), "\n")

# -------------------------------
# Exercise 2 - Call Center (Poisson)
# -------------------------------
lambda <- 12

# i. Random Variable
cat("\nExercise 2 (i): X = number of calls received per hour\n")

# ii. Distribution
cat("Exercise 2 (ii): X ~ Poisson(", lambda, ")\n")

# iii. P(X = 15)
cat("Exercise 2 (iii): P(X=15) =", dpois(15, lambda), "\n")
